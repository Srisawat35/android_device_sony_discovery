TWRP device configuration for Sony Xperia XA2 Ultra
==============
